import localforage from 'localforage';
import type { Invoice, CompanySettings } from '../types';

// Configure localforage
localforage.config({
  name: 'ACInvoiceApp',
  storeName: 'invoices',
});

const INVOICES_KEY = 'invoices';
const SETTINGS_KEY = 'company_settings';
const INVOICE_COUNTER_KEY = 'invoice_counter';

// Company Settings
export async function getCompanySettings(): Promise<CompanySettings> {
  const settings = await localforage.getItem<CompanySettings>(SETTINGS_KEY);
  return settings || {
    name: 'Your AC Company',
    phone: '+971 XX XXX XXXX',
    email: 'info@example.com',
    address: 'Dubai, UAE',
  };
}

export async function saveCompanySettings(settings: CompanySettings): Promise<void> {
  await localforage.setItem(SETTINGS_KEY, settings);
}

// Invoice Counter for generating unique numbers
export async function getNextInvoiceNumber(): Promise<string> {
  let counter = await localforage.getItem<number>(INVOICE_COUNTER_KEY) || 0;
  counter += 1;
  await localforage.setItem(INVOICE_COUNTER_KEY, counter);
  
  const date = new Date();
  const year = date.getFullYear().toString().slice(-2);
  const month = String(date.getMonth() + 1).padStart(2, '0');
  
  return `INV-${year}${month}-${String(counter).padStart(4, '0')}`;
}

// Invoices
export async function getAllInvoices(): Promise<Invoice[]> {
  const invoices = await localforage.getItem<Invoice[]>(INVOICES_KEY);
  return invoices || [];
}

export async function getInvoiceById(id: string): Promise<Invoice | null> {
  const invoices = await getAllInvoices();
  return invoices.find(inv => inv.id === id) || null;
}

export async function saveInvoice(invoice: Invoice): Promise<void> {
  const invoices = await getAllInvoices();
  const existingIndex = invoices.findIndex(inv => inv.id === invoice.id);
  
  if (existingIndex >= 0) {
    invoices[existingIndex] = invoice;
  } else {
    invoices.unshift(invoice);
  }
  
  await localforage.setItem(INVOICES_KEY, invoices);
}

export async function deleteInvoice(id: string): Promise<void> {
  const invoices = await getAllInvoices();
  const filtered = invoices.filter(inv => inv.id !== id);
  await localforage.setItem(INVOICES_KEY, filtered);
}

export async function updateInvoiceStatus(id: string, status: 'paid' | 'unpaid'): Promise<void> {
  const invoices = await getAllInvoices();
  const invoice = invoices.find(inv => inv.id === id);
  if (invoice) {
    invoice.status = status;
    await localforage.setItem(INVOICES_KEY, invoices);
  }
}
