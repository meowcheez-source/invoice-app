export interface CompanySettings {
  name: string;
  phone: string;
  email: string;
  address: string;
  logo?: string;
  vatNumber?: string;
}

export interface ServiceItem {
  id: string;
  description: string;
  serviceType: ServiceType;
  quantity: number;
  price: number;
}

export type ServiceType = 
  | 'AC Installation'
  | 'AC Repair'
  | 'Gas Filling'
  | 'AC Maintenance'
  | 'General Service';

export interface Customer {
  name: string;
  phone: string;
  address: string;
}

export interface Invoice {
  id: string;
  invoiceNumber: string;
  date: string;
  customer: Customer;
  items: ServiceItem[];
  subtotal: number;
  vatAmount: number;
  total: number;
  includeVat: boolean;
  status: 'paid' | 'unpaid';
  signature?: string;
  notes?: string;
}

export type ViewState = 'form' | 'preview' | 'history' | 'settings';
